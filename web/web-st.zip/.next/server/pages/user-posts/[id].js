module.exports =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = require('../../ssr-module-cache.js');
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		var threw = true;
/******/ 		try {
/******/ 			modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 			threw = false;
/******/ 		} finally {
/******/ 			if(threw) delete installedModules[moduleId];
/******/ 		}
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 12);
/******/ })
/************************************************************************/
/******/ ({

/***/ "/jkW":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


exports.__esModule = true;
exports.isDynamicRoute = isDynamicRoute; // Identify /[param]/ in route string

const TEST_ROUTE = /\/\[[^/]+?\](?=\/|$)/;

function isDynamicRoute(route) {
  return TEST_ROUTE.test(route);
}

/***/ }),

/***/ "0Bsm":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _interopRequireDefault = __webpack_require__("AroE");

exports.__esModule = true;
exports.default = withRouter;

var _react = _interopRequireDefault(__webpack_require__("cDcd"));

var _router = __webpack_require__("nOHt");

function withRouter(ComposedComponent) {
  function WithRouterWrapper(props) {
    return /*#__PURE__*/_react.default.createElement(ComposedComponent, Object.assign({
      router: (0, _router.useRouter)()
    }, props));
  }

  WithRouterWrapper.getInitialProps = ComposedComponent.getInitialProps // This is needed to allow checking for custom getInitialProps in _app
  ;
  WithRouterWrapper.origGetInitialProps = ComposedComponent.origGetInitialProps;

  if (false) {}

  return WithRouterWrapper;
}

/***/ }),

/***/ 12:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("eE/z");


/***/ }),

/***/ "4Q3z":
/***/ (function(module, exports) {

module.exports = require("next/router");

/***/ }),

/***/ "4Tsm":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return EditDeletePostButtons; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("cDcd");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _chakra_ui_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("WKWs");
/* harmony import */ var _chakra_ui_core__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_chakra_ui_core__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("YFqc");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _generated_graphql__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("pHx+");
var __jsx = react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement;




const EditDeletePostButtons = ({
  id,
  creatorId,
  updaterId
}) => {
  var _meData$me;

  const [{
    data: meData
  }] = Object(_generated_graphql__WEBPACK_IMPORTED_MODULE_3__[/* useMeQuery */ "k"])();
  const [, deletePost] = Object(_generated_graphql__WEBPACK_IMPORTED_MODULE_3__[/* useDeletePostMutation */ "f"])(); // const [{data: userData}] = useUserQuery({
  //   variables:{
  //     id : meData?.me?.id as number
  //   }
  // })

  var url = "";

  if ((meData === null || meData === void 0 ? void 0 : (_meData$me = meData.me) === null || _meData$me === void 0 ? void 0 : _meData$me.id) == null) {
    return null;
  } // if(updaterId && creatorId == 1 || meData.me.id !== updaterId){


  if (updaterId == 1 || updaterId == meData.me.id) {
    url = "/post/edit/";
  } // if(meData.me.id == creatorId){
  //   return(
  //     <Box>
  //       <NextLink href={url} as={url+id}>
  //         <IconButton as={Link} mr={4} icon="edit" aria-label="Edit Post" />
  //       </NextLink>
  //       <IconButton
  //         icon="delete"
  //         aria-label="Delete Post"
  //         onClick={() => {
  //           deletePost({ id });
  //         }}
  //       />
  //     </Box>
  //   );
  // }
  else if (meData.me.role === "Reviewer" || meData.me.active === "0") {
      return null;
    } else {
      url = "/post/";
    }

  return __jsx(_chakra_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
    alignSelf: 'center'
  }, __jsx(next_link__WEBPACK_IMPORTED_MODULE_2___default.a, {
    href: url + id,
    as: url + id
  }, __jsx(_chakra_ui_core__WEBPACK_IMPORTED_MODULE_1__["IconButton"], {
    as: _chakra_ui_core__WEBPACK_IMPORTED_MODULE_1__["Link"],
    mr: 4,
    icon: "edit",
    "aria-label": "Edit Post",
    variantColor: "orange"
  })));
};

/***/ }),

/***/ "5Mv4":
/***/ (function(module, exports) {

module.exports = require("react-audio-player");

/***/ }),

/***/ "5X2e":
/***/ (function(module, exports) {

module.exports = require("urql");

/***/ }),

/***/ "6D7l":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


exports.__esModule = true;
exports.formatUrl = formatUrl;

var _querystring = __webpack_require__("8xkj"); // Format function modified from nodejs
// Copyright Joyent, Inc. and other Node contributors.
//
// Permission is hereby granted, free of charge, to any person obtaining a
// copy of this software and associated documentation files (the
// "Software"), to deal in the Software without restriction, including
// without limitation the rights to use, copy, modify, merge, publish,
// distribute, sublicense, and/or sell copies of the Software, and to permit
// persons to whom the Software is furnished to do so, subject to the
// following conditions:
//
// The above copyright notice and this permission notice shall be included
// in all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
// OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
// MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN
// NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
// DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
// OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE
// USE OR OTHER DEALINGS IN THE SOFTWARE.


const slashedProtocols = /https?|ftp|gopher|file/;

function formatUrl(urlObj) {
  let {
    auth,
    hostname
  } = urlObj;
  let protocol = urlObj.protocol || '';
  let pathname = urlObj.pathname || '';
  let hash = urlObj.hash || '';
  let query = urlObj.query || '';
  let host = false;
  auth = auth ? encodeURIComponent(auth).replace(/%3A/i, ':') + '@' : '';

  if (urlObj.host) {
    host = auth + urlObj.host;
  } else if (hostname) {
    host = auth + (~hostname.indexOf(':') ? `[${hostname}]` : hostname);

    if (urlObj.port) {
      host += ':' + urlObj.port;
    }
  }

  if (query && typeof query === 'object') {
    // query = '' + new URLSearchParams(query);
    query = (0, _querystring.encode)(query);
  }

  let search = urlObj.search || query && `?${query}` || '';
  if (protocol && protocol.substr(-1) !== ':') protocol += ':';

  if (urlObj.slashes || (!protocol || slashedProtocols.test(protocol)) && host !== false) {
    host = '//' + (host || '');
    if (pathname && pathname[0] !== '/') pathname = '/' + pathname;
  } else if (!host) {
    host = '';
  }

  if (hash && hash[0] !== '#') hash = '#' + hash;
  if (search && search[0] !== '?') search = '?' + search;
  pathname = pathname.replace(/[?#]/g, encodeURIComponent);
  search = search.replace('#', '%23');
  return `${protocol}${host}${pathname}${search}${hash}`;
}

/***/ }),

/***/ "7KCV":
/***/ (function(module, exports, __webpack_require__) {

var _typeof = __webpack_require__("C+bE");

function _getRequireWildcardCache() {
  if (typeof WeakMap !== "function") return null;
  var cache = new WeakMap();

  _getRequireWildcardCache = function _getRequireWildcardCache() {
    return cache;
  };

  return cache;
}

function _interopRequireWildcard(obj) {
  if (obj && obj.__esModule) {
    return obj;
  }

  if (obj === null || _typeof(obj) !== "object" && typeof obj !== "function") {
    return {
      "default": obj
    };
  }

  var cache = _getRequireWildcardCache();

  if (cache && cache.has(obj)) {
    return cache.get(obj);
  }

  var newObj = {};
  var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor;

  for (var key in obj) {
    if (Object.prototype.hasOwnProperty.call(obj, key)) {
      var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null;

      if (desc && (desc.get || desc.set)) {
        Object.defineProperty(newObj, key, desc);
      } else {
        newObj[key] = obj[key];
      }
    }
  }

  newObj["default"] = obj;

  if (cache) {
    cache.set(obj, newObj);
  }

  return newObj;
}

module.exports = _interopRequireWildcard;

/***/ }),

/***/ "8xkj":
/***/ (function(module, exports) {

module.exports = require("querystring");

/***/ }),

/***/ "9LYk":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, "a", function() { return /* binding */ createUrqlClient; });

// EXTERNAL MODULE: external "@urql/exchange-graphcache"
var exchange_graphcache_ = __webpack_require__("ULzA");

// EXTERNAL MODULE: external "urql"
var external_urql_ = __webpack_require__("5X2e");

// EXTERNAL MODULE: external "wonka"
var external_wonka_ = __webpack_require__("DbN8");

// EXTERNAL MODULE: ./src/generated/graphql.tsx
var graphql = __webpack_require__("pHx+");

// CONCATENATED MODULE: ./src/utils/betterUpdateQuery.tsx
function betterUpdateQuery(cache, qi, result, fn) {
  return cache.updateQuery(qi, data => fn(result, data));
}
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__("4Q3z");
var router_default = /*#__PURE__*/__webpack_require__.n(router_);

// EXTERNAL MODULE: external "graphql-tag"
var external_graphql_tag_ = __webpack_require__("txk1");
var external_graphql_tag_default = /*#__PURE__*/__webpack_require__.n(external_graphql_tag_);

// EXTERNAL MODULE: ./src/utils/isServer.ts
var isServer = __webpack_require__("OXnp");

// CONCATENATED MODULE: ./src/utils/createUrqlClient.ts









const errorExchange = ({
  forward
}) => ops$ => {
  return Object(external_wonka_["pipe"])(forward(ops$), Object(external_wonka_["tap"])(({
    error
  }) => {
    if (error === null || error === void 0 ? void 0 : error.message.includes("not authenticated")) {
      router_default.a.replace("/login");
    }
  }));
};

const cursorPagination = gqlquery => {
  return (_parent, fieldArgs, cache, info) => {
    const {
      parentKey: entityKey,
      fieldName
    } = info; // console.log("key   :", entityKey, "field   :", fieldName);

    const allFields = cache.inspectFields(entityKey); // console.log("allFields   :", allFields);

    const fieldInfos = allFields.filter(info => info.fieldName === fieldName);
    const size = fieldInfos.length;

    if (size === 0) {
      return undefined;
    }

    const fieldKey = `${fieldName}(${Object(external_urql_["stringifyVariables"])(fieldArgs)})`;
    const isItInTheCache = cache.resolve(cache.resolveFieldByKey(entityKey, fieldKey), gqlquery);
    info.partial = !isItInTheCache;
    let hasMore = true;
    const results = [];
    fieldInfos.forEach(fi => {
      const key = cache.resolveFieldByKey(entityKey, fi.fieldKey);
      const data = cache.resolve(key, gqlquery);

      const _hasMore = cache.resolve(key, "hasMore");

      if (!_hasMore) {
        hasMore = _hasMore;
      }

      results.push(...data);
    });
    return {
      __typename: "PaginatedPosts",
      hasMore,
      posts: results
    };
  };
};

function invalidateAllPosts(cache) {
  const allFields = cache.inspectFields("Query");
  const fieldInfos = allFields.filter(info => info.fieldName === "posts");
  fieldInfos.forEach(fi => {
    cache.invalidate("Query", "posts", fi.arguments || {});
  });
}

const createUrqlClient = (ssrExchange, ctx) => {
  let cookie = "";

  if (Object(isServer["a" /* isServer */])()) {
    var _ctx$req, _ctx$req$headers;

    cookie = ctx === null || ctx === void 0 ? void 0 : (_ctx$req = ctx.req) === null || _ctx$req === void 0 ? void 0 : (_ctx$req$headers = _ctx$req.headers) === null || _ctx$req$headers === void 0 ? void 0 : _ctx$req$headers.cookie;
  }

  return {
    url: "https://api.oook.sd/graphql",
    fetchOptions: {
      credentials: "include",
      headers: cookie ? {
        cookie
      } : undefined
    },
    exchanges: [external_urql_["dedupExchange"], Object(exchange_graphcache_["cacheExchange"])({
      keys: {
        PaginatedPosts: () => null
      },
      resolvers: {
        Query: {
          posts: cursorPagination("posts"),
          userposts: cursorPagination("posts"),
          // uservotedposts: cursorPagination("votedposts"),
          votableposts: cursorPagination("posts"),
          editableposts: cursorPagination("posts")
        }
      },
      updates: {
        Mutation: {
          deletePost: (_result, args, cache, info) => {
            cache.invalidate({
              __typename: "Post",
              id: args.id
            });
          },
          vote: (_result, args, cache, info) => {
            const {
              postId,
              value
            } = args;
            const data = cache.readFragment(external_graphql_tag_default.a`
                  fragment _ on Post {
                    id
                    points
                    voteStatus
                  }
                `, {
              id: postId
            });

            if (data) {
              if (data.voteStatus === value) {
                return;
              }

              const newPoints = data.points + (!data.voteStatus ? 1 : 2) * value;
              cache.writeFragment(external_graphql_tag_default.a`
                    fragment __ on Post {
                      points
                      voteStatus
                    }
                  `, {
                id: postId,
                points: newPoints,
                voteStatus: value
              });
            }
          },
          createPost: (_result, args, cache, info) => {
            invalidateAllPosts(cache);
          },
          logout: (_result, args, cache, info) => {
            betterUpdateQuery(cache, {
              query: graphql["a" /* MeDocument */]
            }, _result, () => ({
              me: null
            }));
          },
          login: (_result, args, cache, info) => {
            betterUpdateQuery(cache, {
              query: graphql["a" /* MeDocument */]
            }, _result, (result, query) => {
              if (result.login.errors) {
                return query;
              } else {
                return {
                  me: result.login.user
                };
              }
            });
            invalidateAllPosts(cache);
          },
          register: (_result, args, cache, info) => {
            betterUpdateQuery(cache, {
              query: graphql["a" /* MeDocument */]
            }, _result, (result, query) => {
              if (result.register.errors) {
                return query;
              } else {
                return {
                  me: result.register.user
                };
              }
            });
          }
        }
      }
    }), errorExchange, ssrExchange, external_urql_["fetchExchange"]]
  };
};

/***/ }),

/***/ "AroE":
/***/ (function(module, exports) {

function _interopRequireDefault(obj) {
  return obj && obj.__esModule ? obj : {
    "default": obj
  };
}

module.exports = _interopRequireDefault;

/***/ }),

/***/ "C+bE":
/***/ (function(module, exports) {

function _typeof(obj) {
  "@babel/helpers - typeof";

  if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") {
    module.exports = _typeof = function _typeof(obj) {
      return typeof obj;
    };
  } else {
    module.exports = _typeof = function _typeof(obj) {
      return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj;
    };
  }

  return _typeof(obj);
}

module.exports = _typeof;

/***/ }),

/***/ "DGsd":
/***/ (function(module, exports) {

module.exports = require("next-urql");

/***/ }),

/***/ "DbN8":
/***/ (function(module, exports) {

module.exports = require("wonka");

/***/ }),

/***/ "H7a7":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return UpdootSection; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("cDcd");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _chakra_ui_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("WKWs");
/* harmony import */ var _chakra_ui_core__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_chakra_ui_core__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _generated_graphql__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("pHx+");
var __jsx = react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement;



const UpdootSection = ({
  post,
  updaterid,
  direction,
  disabled
}) => {
  var _meData$me, _meData$me2, _meData$me3;

  const {
    0: loadingState,
    1: setLoadingState
  } = Object(react__WEBPACK_IMPORTED_MODULE_0__["useState"])("not-loading");
  const [, vote] = Object(_generated_graphql__WEBPACK_IMPORTED_MODULE_2__[/* useVoteMutation */ "v"])();
  const [{
    data: meData
  }] = Object(_generated_graphql__WEBPACK_IMPORTED_MODULE_2__[/* useMeQuery */ "k"])();

  if ((meData === null || meData === void 0 ? void 0 : (_meData$me = meData.me) === null || _meData$me === void 0 ? void 0 : _meData$me.id) == null || updaterid == 1) {
    return null;
  }

  if ((meData === null || meData === void 0 ? void 0 : (_meData$me2 = meData.me) === null || _meData$me2 === void 0 ? void 0 : _meData$me2.role) === "admin" || (meData === null || meData === void 0 ? void 0 : (_meData$me3 = meData.me) === null || _meData$me3 === void 0 ? void 0 : _meData$me3.role) === "Reviewer") {
    return __jsx(_chakra_ui_core__WEBPACK_IMPORTED_MODULE_1__["Flex"], {
      direction: direction ? "column" : "row",
      justifyContent: "center",
      alignItems: "center",
      mr: 4
    }, __jsx(_chakra_ui_core__WEBPACK_IMPORTED_MODULE_1__["IconButton"], {
      isDisabled: disabled,
      m: 2,
      onClick: async () => {
        if (post.voteStatus === 1) {
          return;
        }

        setLoadingState("updoot-loading");
        await vote({
          postId: post.id,
          value: 1
        });
        setLoadingState("not-loading");
      },
      variantColor: post.voteStatus === 1 ? "green" : undefined,
      isLoading: loadingState === "updoot-loading",
      "aria-label": "updoot post",
      icon: "check"
    }), post.points, __jsx(_chakra_ui_core__WEBPACK_IMPORTED_MODULE_1__["IconButton"], {
      isDisabled: disabled,
      m: 2,
      onClick: async () => {
        if (post.voteStatus === -1) {
          return;
        }

        setLoadingState("downdoot-loading");
        await vote({
          postId: post.id,
          value: -1
        });
        setLoadingState("not-loading");
      },
      variantColor: post.voteStatus === -1 ? "red" : undefined,
      isLoading: loadingState === "downdoot-loading",
      "aria-label": "downdoot post",
      icon: "small-close"
    }));
  } else {
    return null;
  } // return (
  //   <Flex direction="column" justifyContent="center" alignItems="center" mr={4}>
  //     <IconButton
  //       onClick={async () => {
  //         if (post.voteStatus === 1) {
  //           return;
  //         }
  //         setLoadingState("updoot-loading");
  //         await vote({
  //           postId: post.id,
  //           value: 1,
  //         });
  //         setLoadingState("not-loading");
  //       }}
  //       variantColor={post.voteStatus === 1 ? "green" : undefined}
  //       isLoading={loadingState === "updoot-loading"}
  //       aria-label="updoot post"
  //       icon="chevron-up"
  //     />
  //     {post.points}
  //     <IconButton
  //       onClick={async () => {
  //         if (post.voteStatus === -1) {
  //           return;
  //         }
  //         setLoadingState("downdoot-loading");
  //         await vote({
  //           postId: post.id,
  //           value: -1,
  //         });
  //         setLoadingState("not-loading");
  //       }}
  //       variantColor={post.voteStatus === -1 ? "red" : undefined}
  //       isLoading={loadingState === "downdoot-loading"}
  //       aria-label="downdoot post"
  //       icon="chevron-down"
  //     />
  //   </Flex>
  // );

};

/***/ }),

/***/ "HdUH":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return UserPostsDurations; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("cDcd");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _chakra_ui_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("WKWs");
/* harmony import */ var _chakra_ui_core__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_chakra_ui_core__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _generated_graphql__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("pHx+");
/* harmony import */ var _utils_calculateTime__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("me3I");
var __jsx = react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement;




const UserPostsDurations = ({
  updaterId
}) => {
  const [{
    data: durData
  }] = Object(_generated_graphql__WEBPACK_IMPORTED_MODULE_2__[/* useUserDurationsQuery */ "p"])({
    variables: {
      updaterId: updaterId
    }
  });
  return __jsx(_chakra_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], null, __jsx(_chakra_ui_core__WEBPACK_IMPORTED_MODULE_1__["Heading"], {
    fontSize: "xl"
  }, "Submited posts : ", durData === null || durData === void 0 ? void 0 : durData.userdurations[0].count, " post/s"), __jsx(_chakra_ui_core__WEBPACK_IMPORTED_MODULE_1__["Text"], null, "Total posts time :", " ", Object(_utils_calculateTime__WEBPACK_IMPORTED_MODULE_3__[/* calculateTime */ "a"])(Math.floor(durData === null || durData === void 0 ? void 0 : durData.userdurations[0].sum))));
};

/***/ }),

/***/ "OXnp":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return isServer; });
const isServer = () => true;

/***/ }),

/***/ "Osoz":
/***/ (function(module, exports) {

module.exports = require("next/dist/next-server/lib/router-context.js");

/***/ }),

/***/ "ULzA":
/***/ (function(module, exports) {

module.exports = require("@urql/exchange-graphcache");

/***/ }),

/***/ "WKWs":
/***/ (function(module, exports) {

module.exports = require("@chakra-ui/core");

/***/ }),

/***/ "X24+":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


exports.__esModule = true;
exports.removePathTrailingSlash = removePathTrailingSlash;
exports.normalizePathTrailingSlash = void 0;
/**
* Removes the trailing slash of a path if there is one. Preserves the root path `/`.
*/

function removePathTrailingSlash(path) {
  return path.endsWith('/') && path !== '/' ? path.slice(0, -1) : path;
}
/**
* Normalizes the trailing slash of a path according to the `trailingSlash` option
* in `next.config.js`.
*/


const normalizePathTrailingSlash =  false ? undefined : removePathTrailingSlash;
exports.normalizePathTrailingSlash = normalizePathTrailingSlash;

/***/ }),

/***/ "YFqc":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("cTJO")


/***/ }),

/***/ "YTqd":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


exports.__esModule = true;
exports.getRouteRegex = getRouteRegex; // this isn't importing the escape-string-regex module
// to reduce bytes

function escapeRegex(str) {
  return str.replace(/[|\\{}()[\]^$+*?.-]/g, '\\$&');
}

function parseParameter(param) {
  const optional = param.startsWith('[') && param.endsWith(']');

  if (optional) {
    param = param.slice(1, -1);
  }

  const repeat = param.startsWith('...');

  if (repeat) {
    param = param.slice(3);
  }

  return {
    key: param,
    repeat,
    optional
  };
}

function getRouteRegex(normalizedRoute) {
  const segments = (normalizedRoute.replace(/\/$/, '') || '/').slice(1).split('/');
  const groups = {};
  let groupIndex = 1;
  const parameterizedRoute = segments.map(segment => {
    if (segment.startsWith('[') && segment.endsWith(']')) {
      const {
        key,
        optional,
        repeat
      } = parseParameter(segment.slice(1, -1));
      groups[key] = {
        pos: groupIndex++,
        repeat,
        optional
      };
      return repeat ? optional ? '(?:/(.+?))?' : '/(.+?)' : '/([^/]+?)';
    } else {
      return `/${escapeRegex(segment)}`;
    }
  }).join(''); // dead code eliminate for browser since it's only needed
  // while generating routes-manifest

  if (true) {
    let routeKeyCharCode = 97;
    let routeKeyCharLength = 1; // builds a minimal routeKey using only a-z and minimal number of characters

    const getSafeRouteKey = () => {
      let routeKey = '';

      for (let i = 0; i < routeKeyCharLength; i++) {
        routeKey += String.fromCharCode(routeKeyCharCode);
        routeKeyCharCode++;

        if (routeKeyCharCode > 122) {
          routeKeyCharLength++;
          routeKeyCharCode = 97;
        }
      }

      return routeKey;
    };

    const routeKeys = {};
    let namedParameterizedRoute = segments.map(segment => {
      if (segment.startsWith('[') && segment.endsWith(']')) {
        const {
          key,
          optional,
          repeat
        } = parseParameter(segment.slice(1, -1)); // replace any non-word characters since they can break
        // the named regex

        let cleanedKey = key.replace(/\W/g, '');
        let invalidKey = false; // check if the key is still invalid and fallback to using a known
        // safe key

        if (cleanedKey.length === 0 || cleanedKey.length > 30) {
          invalidKey = true;
        }

        if (!isNaN(parseInt(cleanedKey.substr(0, 1)))) {
          invalidKey = true;
        }

        if (invalidKey) {
          cleanedKey = getSafeRouteKey();
        }

        routeKeys[cleanedKey] = key;
        return repeat ? optional ? `(?:/(?<${cleanedKey}>.+?))?` : `/(?<${cleanedKey}>.+?)` : `/(?<${cleanedKey}>[^/]+?)`;
      } else {
        return `/${escapeRegex(segment)}`;
      }
    }).join('');
    return {
      re: new RegExp(`^${parameterizedRoute}(?:/)?$`),
      groups,
      routeKeys,
      namedRegex: `^${namedParameterizedRoute}(?:/)?$`
    };
  }

  return {
    re: new RegExp(`^${parameterizedRoute}(?:/)?$`),
    groups
  };
}

/***/ }),

/***/ "ZG8H":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return useGetUserFromUrl; });
/* harmony import */ var _generated_graphql__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("pHx+");
/* harmony import */ var _useGetIntId__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("xKEG");


const useGetUserFromUrl = () => {
  const intId = Object(_useGetIntId__WEBPACK_IMPORTED_MODULE_1__[/* useGetIntId */ "a"])();
  return Object(_generated_graphql__WEBPACK_IMPORTED_MODULE_0__[/* useUserQuery */ "r"])({
    pause: intId === -1,
    variables: {
      id: intId
    }
  });
};

/***/ }),

/***/ "cDcd":
/***/ (function(module, exports) {

module.exports = require("react");

/***/ }),

/***/ "cE6r":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


exports.__esModule = true;
exports.searchParamsToUrlQuery = searchParamsToUrlQuery;

function searchParamsToUrlQuery(searchParams) {
  const query = {};
  searchParams.forEach((value, key) => {
    if (typeof query[key] === 'undefined') {
      query[key] = value;
    } else if (Array.isArray(query[key])) {
      ;
      query[key].push(value);
    } else {
      query[key] = [query[key], value];
    }
  });
  return query;
}

/***/ }),

/***/ "cTJO":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _interopRequireWildcard = __webpack_require__("7KCV");

exports.__esModule = true;
exports.default = void 0;

var _react = _interopRequireWildcard(__webpack_require__("cDcd"));

var _utils = __webpack_require__("kYf9");

var _router = __webpack_require__("nOHt");

var _router2 = __webpack_require__("elyg");
/**
* Detects whether a given url is from the same origin as the current page (browser only).
*/


function isLocal(url) {
  const locationOrigin = (0, _utils.getLocationOrigin)();
  const resolved = new URL(url, locationOrigin);
  return resolved.origin === locationOrigin;
}

let cachedObserver;
const listeners = new Map();
const IntersectionObserver = false ? undefined : null;
const prefetched = {};

function getObserver() {
  // Return shared instance of IntersectionObserver if already created
  if (cachedObserver) {
    return cachedObserver;
  } // Only create shared IntersectionObserver if supported in browser


  if (!IntersectionObserver) {
    return undefined;
  }

  return cachedObserver = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if (!listeners.has(entry.target)) {
        return;
      }

      const cb = listeners.get(entry.target);

      if (entry.isIntersecting || entry.intersectionRatio > 0) {
        cachedObserver.unobserve(entry.target);
        listeners.delete(entry.target);
        cb();
      }
    });
  }, {
    rootMargin: '200px'
  });
}

const listenToIntersections = (el, cb) => {
  const observer = getObserver();

  if (!observer) {
    return () => {};
  }

  observer.observe(el);
  listeners.set(el, cb);
  return () => {
    try {
      observer.unobserve(el);
    } catch (err) {
      console.error(err);
    }

    listeners.delete(el);
  };
};

function prefetch(router, href, as, options) {
  if (true) return; // Prefetch the JSON page if asked (only in the client)
  // We need to handle a prefetch error here since we may be
  // loading with priority which can reject but we don't
  // want to force navigation since this is only a prefetch

  router.prefetch(href, as, options).catch(err => {
    if (false) {}
  }); // Join on an invalid URI character

  prefetched[href + '%' + as] = true;
}

function linkClicked(e, router, href, as, replace, shallow, scroll) {
  const {
    nodeName,
    target
  } = e.currentTarget;

  if (nodeName === 'A' && (target && target !== '_self' || e.metaKey || e.ctrlKey || e.shiftKey || e.nativeEvent && e.nativeEvent.which === 2)) {
    // ignore click for new tab / new window behavior
    return;
  }

  if (!isLocal(href)) {
    // ignore click if it's outside our scope (e.g. https://google.com)
    return;
  }

  e.preventDefault(); //  avoid scroll for urls with anchor refs

  if (scroll == null) {
    scroll = as.indexOf('#') < 0;
  } // replace state instead of push if prop is present


  router[replace ? 'replace' : 'push'](href, as, {
    shallow
  }).then(success => {
    if (!success) return;

    if (scroll) {
      window.scrollTo(0, 0);
      document.body.focus();
    }
  });
}

function Link(props) {
  if (false) {}

  const p = props.prefetch !== false;

  const [childElm, setChildElm] = _react.default.useState();

  const router = (0, _router.useRouter)();
  const pathname = router && router.pathname || '/';

  const {
    href,
    as
  } = _react.default.useMemo(() => {
    const resolvedHref = (0, _router2.resolveHref)(pathname, props.href);
    return {
      href: resolvedHref,
      as: props.as ? (0, _router2.resolveHref)(pathname, props.as) : resolvedHref
    };
  }, [pathname, props.href, props.as]);

  _react.default.useEffect(() => {
    if (p && IntersectionObserver && childElm && childElm.tagName) {
      // Join on an invalid URI character
      const isPrefetched = prefetched[href + '%' + as];

      if (!isPrefetched) {
        return listenToIntersections(childElm, () => {
          prefetch(router, href, as);
        });
      }
    }
  }, [p, childElm, href, as, router]);

  let {
    children,
    replace,
    shallow,
    scroll
  } = props; // Deprecated. Warning shown by propType check. If the children provided is a string (<Link>example</Link>) we wrap it in an <a> tag

  if (typeof children === 'string') {
    children = /*#__PURE__*/_react.default.createElement("a", null, children);
  } // This will return the first child, if multiple are provided it will throw an error


  const child = _react.Children.only(children);

  const childProps = {
    ref: el => {
      if (el) setChildElm(el);

      if (child && typeof child === 'object' && child.ref) {
        if (typeof child.ref === 'function') child.ref(el);else if (typeof child.ref === 'object') {
          child.ref.current = el;
        }
      }
    },
    onClick: e => {
      if (child.props && typeof child.props.onClick === 'function') {
        child.props.onClick(e);
      }

      if (!e.defaultPrevented) {
        linkClicked(e, router, href, as, replace, shallow, scroll);
      }
    }
  };

  if (p) {
    childProps.onMouseEnter = e => {
      if (child.props && typeof child.props.onMouseEnter === 'function') {
        child.props.onMouseEnter(e);
      }

      prefetch(router, href, as, {
        priority: true
      });
    };
  } // If child is an <a> tag and doesn't have a href attribute, or if the 'passHref' property is
  // defined, we specify the current 'href', so that repetition is not needed by the user


  if (props.passHref || child.type === 'a' && !('href' in child.props)) {
    childProps.href = (0, _router2.addBasePath)(as);
  } // Add the ending slash to the paths. So, we can serve the
  // "<page>/index.html" directly.


  if (false) {}

  return _react.default.cloneElement(child, childProps);
}

if (false) {}

var _default = Link;
exports.default = _default;

/***/ }),

/***/ "dZ6Y":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


exports.__esModule = true;
exports.default = mitt;
/*
MIT License
Copyright (c) Jason Miller (https://jasonformat.com/)
Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:
The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.
THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/
// This file is based on https://github.com/developit/mitt/blob/v1.1.3/src/index.js
// It's been edited for the needs of this script
// See the LICENSE at the top of the file

function mitt() {
  const all = Object.create(null);
  return {
    on(type, handler) {
      ;
      (all[type] || (all[type] = [])).push(handler);
    },

    off(type, handler) {
      if (all[type]) {
        // tslint:disable-next-line:no-bitwise
        all[type].splice(all[type].indexOf(handler) >>> 0, 1);
      }
    },

    emit(type, ...evts) {
      // eslint-disable-next-line array-callback-return
      ;
      (all[type] || []).slice().map(handler => {
        handler(...evts);
      });
    }

  };
}

/***/ }),

/***/ "eE/z":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(__dirname) {/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("cDcd");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _chakra_ui_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("WKWs");
/* harmony import */ var _chakra_ui_core__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_chakra_ui_core__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_urql__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("DGsd");
/* harmony import */ var next_urql__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_urql__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _components_Layout__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("soUV");
/* harmony import */ var _generated_graphql__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__("pHx+");
/* harmony import */ var _utils_createUrqlClient__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__("9LYk");
/* harmony import */ var path__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__("oyvS");
/* harmony import */ var path__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(path__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _utils_useGetUserFromUrl__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__("ZG8H");
/* harmony import */ var _components_UserPosts__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__("ypBt");

var __jsx = react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement;










const UserPostsDetails = () => {
  var _meData$me, _meData$me2;

  const [{
    data: udata
  }] = Object(_utils_useGetUserFromUrl__WEBPACK_IMPORTED_MODULE_7__[/* useGetUserFromUrl */ "a"])();
  const [{
    data: meData
  }] = Object(_generated_graphql__WEBPACK_IMPORTED_MODULE_4__[/* useMeQuery */ "k"])();
  const {
    0: variables,
    1: setVariables
  } = Object(react__WEBPACK_IMPORTED_MODULE_0__["useState"])({
    updaterId: meData === null || meData === void 0 ? void 0 : (_meData$me = meData.me) === null || _meData$me === void 0 ? void 0 : _meData$me.id,
    limit: 15,
    cursor: null
  });
  const [{
    data,
    error,
    fetching
  }] = Object(_generated_graphql__WEBPACK_IMPORTED_MODULE_4__[/* useUserPostsQuery */ "q"])({
    variables
  });

  if (!fetching && !data && !meData) {
    return __jsx("div", null, __jsx("div", null, "you got query failed for some reason"), __jsx("div", null, error === null || error === void 0 ? void 0 : error.message));
  }

  if ((meData === null || meData === void 0 ? void 0 : (_meData$me2 = meData.me) === null || _meData$me2 === void 0 ? void 0 : _meData$me2.id) == null) {
    return __jsx(_components_Layout__WEBPACK_IMPORTED_MODULE_3__[/* Layout */ "a"], null, __jsx(_chakra_ui_core__WEBPACK_IMPORTED_MODULE_1__["Flex"], {
      height: 290
    }, __jsx(_chakra_ui_core__WEBPACK_IMPORTED_MODULE_1__["Text"], {
      color: "Red"
    }, "Sorry you are not authorized.. ")));
  }

  if (!(udata === null || udata === void 0 ? void 0 : udata.user)) {
    return __jsx(_components_Layout__WEBPACK_IMPORTED_MODULE_3__[/* Layout */ "a"], null, __jsx(_chakra_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], null, "could not find user"));
  } // const playAudio = async (id) => {
  //   try {
  //     const response = await withUrqlClient.get(`api/getaudio/id/${id}`)
  //     const mp3 = new Blob([response.data], { type: 'audio/mp3' })
  //     const url = window.URL.createObjectURL(mp3)
  //     const audio = new Audio(url)
  //     audio.load()
  //     await audio.play()
  //   } catch (e) {
  //     console.log('play audio error: ', e)
  //   }
  // }
  // return (
  //   <ul>
  //     {props.topList.map(item => (
  //       <li onClick={() => playAudio(item.id)}>{item.title}</li>
  //     ))}
  //   </ul>
  // )


  const audio_path = path__WEBPACK_IMPORTED_MODULE_6___default.a.join(__dirname, "/files/"); // console.log('audio path: ', audio_path)

  return __jsx(_components_Layout__WEBPACK_IMPORTED_MODULE_3__[/* Layout */ "a"], null, udata === null || udata === void 0 ? void 0 : udata.user.map(u => !u ? null : __jsx(_components_UserPosts__WEBPACK_IMPORTED_MODULE_8__[/* UserPosts */ "a"], {
    uid: u.id
  })));
};

/* harmony default export */ __webpack_exports__["default"] = (Object(next_urql__WEBPACK_IMPORTED_MODULE_2__["withUrqlClient"])(_utils_createUrqlClient__WEBPACK_IMPORTED_MODULE_5__[/* createUrqlClient */ "a"], {
  ssr: true
})(UserPostsDetails));
/* WEBPACK VAR INJECTION */}.call(this, "/"))

/***/ }),

/***/ "elyg":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


exports.__esModule = true;
exports.addBasePath = addBasePath;
exports.delBasePath = delBasePath;
exports.resolveHref = resolveHref;
exports.default = void 0;

var _mitt = _interopRequireDefault(__webpack_require__("dZ6Y"));

var _utils = __webpack_require__("g/15");

var _isDynamic = __webpack_require__("/jkW");

var _routeMatcher = __webpack_require__("gguc");

var _routeRegex = __webpack_require__("YTqd");

var _searchParamsToUrlQuery = __webpack_require__("cE6r");

var _parseRelativeUrl = __webpack_require__("hS4m");

var _normalizeTrailingSlash = __webpack_require__("X24+");

function _interopRequireDefault(obj) {
  return obj && obj.__esModule ? obj : {
    default: obj
  };
}
/* global __NEXT_DATA__ */
// tslint:disable:no-console


const basePath =  false || '';

function buildCancellationError() {
  return Object.assign(new Error('Route Cancelled'), {
    cancelled: true
  });
}

function addBasePath(path) {
  return basePath ? path === '/' ? (0, _normalizeTrailingSlash.normalizePathTrailingSlash)(basePath) : basePath + path : path;
}

function delBasePath(path) {
  return path.slice(basePath.length) || '/';
}
/**
* Resolves a given hyperlink with a certain router state (basePath not included).
* Preserves absolute urls.
*/


function resolveHref(currentPath, href) {
  // we use a dummy base url for relative urls
  const base = new URL(currentPath, 'http://n');
  const urlAsString = typeof href === 'string' ? href : (0, _utils.formatWithValidation)(href);
  const finalUrl = new URL(urlAsString, base);
  finalUrl.pathname = (0, _normalizeTrailingSlash.normalizePathTrailingSlash)(finalUrl.pathname); // if the origin didn't change, it means we received a relative href

  return finalUrl.origin === base.origin ? finalUrl.href.slice(finalUrl.origin.length) : finalUrl.href;
}

function prepareUrlAs(router, url, as) {
  // If url and as provided as an object representation,
  // we'll format them into the string version here.
  return {
    url: addBasePath(resolveHref(router.pathname, url)),
    as: as ? addBasePath(resolveHref(router.pathname, as)) : as
  };
}

function tryParseRelativeUrl(url) {
  try {
    return (0, _parseRelativeUrl.parseRelativeUrl)(url);
  } catch (err) {
    if (false) {}

    return null;
  }
}

const manualScrollRestoration =  false && false;

function fetchRetry(url, attempts) {
  return fetch(url, {
    // Cookies are required to be present for Next.js' SSG "Preview Mode".
    // Cookies may also be required for `getServerSideProps`.
    //
    // > `fetch` won’t send cookies, unless you set the credentials init
    // > option.
    // https://developer.mozilla.org/en-US/docs/Web/API/Fetch_API/Using_Fetch
    //
    // > For maximum browser compatibility when it comes to sending &
    // > receiving cookies, always supply the `credentials: 'same-origin'`
    // > option instead of relying on the default.
    // https://github.com/github/fetch#caveats
    credentials: 'same-origin'
  }).then(res => {
    if (!res.ok) {
      if (attempts > 1 && res.status >= 500) {
        return fetchRetry(url, attempts - 1);
      }

      throw new Error(`Failed to load static props`);
    }

    return res.json();
  });
}

function fetchNextData(dataHref, isServerRender) {
  return fetchRetry(dataHref, isServerRender ? 3 : 1).catch(err => {
    // We should only trigger a server-side transition if this was caused
    // on a client-side transition. Otherwise, we'd get into an infinite
    // loop.
    if (!isServerRender) {
      ;
      err.code = 'PAGE_LOAD_ERROR';
    }

    throw err;
  });
}

class Router {
  /**
  * Map of all components loaded in `Router`
  */
  // Static Data Cache
  constructor(_pathname, _query, _as, {
    initialProps,
    pageLoader,
    App,
    wrapApp,
    Component,
    err,
    subscription,
    isFallback
  }) {
    this.route = void 0;
    this.pathname = void 0;
    this.query = void 0;
    this.asPath = void 0;
    this.basePath = void 0;
    this.components = void 0;
    this.sdc = {};
    this.sub = void 0;
    this.clc = void 0;
    this.pageLoader = void 0;
    this._bps = void 0;
    this.events = void 0;
    this._wrapApp = void 0;
    this.isSsr = void 0;
    this.isFallback = void 0;
    this._inFlightRoute = void 0;

    this.onPopState = e => {
      if (!e.state) {
        // We get state as undefined for two reasons.
        //  1. With older safari (< 8) and older chrome (< 34)
        //  2. When the URL changed with #
        //
        // In the both cases, we don't need to proceed and change the route.
        // (as it's already changed)
        // But we can simply replace the state with the new changes.
        // Actually, for (1) we don't need to nothing. But it's hard to detect that event.
        // So, doing the following for (1) does no harm.
        const {
          pathname,
          query
        } = this;
        this.changeState('replaceState', (0, _utils.formatWithValidation)({
          pathname: addBasePath(pathname),
          query
        }), (0, _utils.getURL)());
        return;
      }

      const {
        url,
        as,
        options,
        __N
      } = e.state;

      if (!__N) {
        // this history state wasn't created by next.js so it can be ignored
        return;
      }

      const {
        pathname
      } = (0, _parseRelativeUrl.parseRelativeUrl)(url); // Make sure we don't re-render on initial load,
      // can be caused by navigating back from an external site

      if (this.isSsr && as === this.asPath && pathname === this.pathname) {
        return;
      } // If the downstream application returns falsy, return.
      // They will then be responsible for handling the event.


      if (this._bps && !this._bps(e.state)) {
        return;
      }

      if (false) {}

      this.change('replaceState', url, as, options);
    }; // represents the current component key


    this.route = (0, _normalizeTrailingSlash.removePathTrailingSlash)(_pathname); // set up the component cache (by route keys)

    this.components = {}; // We should not keep the cache, if there's an error
    // Otherwise, this cause issues when when going back and
    // come again to the errored page.

    if (_pathname !== '/_error') {
      this.components[this.route] = {
        Component,
        props: initialProps,
        err,
        __N_SSG: initialProps && initialProps.__N_SSG,
        __N_SSP: initialProps && initialProps.__N_SSP
      };
    }

    this.components['/_app'] = {
      Component: App
    }; // Backwards compat for Router.router.events
    // TODO: Should be remove the following major version as it was never documented

    this.events = Router.events;
    this.pageLoader = pageLoader;
    this.pathname = _pathname;
    this.query = _query; // if auto prerendered and dynamic route wait to update asPath
    // until after mount to prevent hydration mismatch

    this.asPath = // @ts-ignore this is temporarily global (attached to window)
    (0, _isDynamic.isDynamicRoute)(_pathname) && __NEXT_DATA__.autoExport ? _pathname : _as;
    this.basePath = basePath;
    this.sub = subscription;
    this.clc = null;
    this._wrapApp = wrapApp; // make sure to ignore extra popState in safari on navigating
    // back from external site

    this.isSsr = true;
    this.isFallback = isFallback;

    if (false) {}
  } // @deprecated backwards compatibility even though it's a private method.


  static _rewriteUrlForNextExport(url) {
    if (false) {} else {
      return url;
    }
  }

  update(route, mod) {
    const Component = mod.default || mod;
    const data = this.components[route];

    if (!data) {
      throw new Error(`Cannot update unavailable route: ${route}`);
    }

    const newData = Object.assign({}, data, {
      Component,
      __N_SSG: mod.__N_SSG,
      __N_SSP: mod.__N_SSP
    });
    this.components[route] = newData; // pages/_app.js updated

    if (route === '/_app') {
      this.notify(this.components[this.route]);
      return;
    }

    if (route === this.route) {
      this.notify(newData);
    }
  }

  reload() {
    window.location.reload();
  }
  /**
  * Go back in history
  */


  back() {
    window.history.back();
  }
  /**
  * Performs a `pushState` with arguments
  * @param url of the route
  * @param as masks `url` for the browser
  * @param options object you can define `shallow` and other options
  */


  push(url, as = url, options = {}) {
    ;
    ({
      url,
      as
    } = prepareUrlAs(this, url, as));
    return this.change('pushState', url, as, options);
  }
  /**
  * Performs a `replaceState` with arguments
  * @param url of the route
  * @param as masks `url` for the browser
  * @param options object you can define `shallow` and other options
  */


  replace(url, as = url, options = {}) {
    ;
    ({
      url,
      as
    } = prepareUrlAs(this, url, as));
    return this.change('replaceState', url, as, options);
  }

  async change(method, url, as, options) {
    if (!options._h) {
      this.isSsr = false;
    } // marking route changes as a navigation start entry


    if (_utils.ST) {
      performance.mark('routeChange');
    } // Add the ending slash to the paths. So, we can serve the
    // "<page>/index.html" directly for the SSR page.


    if (false) {}

    if (this._inFlightRoute) {
      this.abortComponentLoad(this._inFlightRoute);
    }

    const cleanedAs = delBasePath(as);
    this._inFlightRoute = as; // If the url change is only related to a hash change
    // We should not proceed. We should only change the state.
    // WARNING: `_h` is an internal option for handing Next.js client-side
    // hydration. Your app should _never_ use this property. It may change at
    // any time without notice.

    if (!options._h && this.onlyAHashChange(cleanedAs)) {
      this.asPath = cleanedAs;
      Router.events.emit('hashChangeStart', as);
      this.changeState(method, url, as, options);
      this.scrollToHash(cleanedAs);
      Router.events.emit('hashChangeComplete', as);
      return true;
    }

    const parsed = tryParseRelativeUrl(url);
    if (!parsed) return false;
    let {
      pathname,
      searchParams
    } = parsed;
    const query = (0, _searchParamsToUrlQuery.searchParamsToUrlQuery)(searchParams); // url and as should always be prefixed with basePath by this
    // point by either next/link or router.push/replace so strip the
    // basePath from the pathname to match the pages dir 1-to-1

    pathname = pathname ? (0, _normalizeTrailingSlash.removePathTrailingSlash)(delBasePath(pathname)) : pathname; // If asked to change the current URL we should reload the current page
    // (not location.reload() but reload getInitialProps and other Next.js stuffs)
    // We also need to set the method = replaceState always
    // as this should not go into the history (That's how browsers work)
    // We should compare the new asPath to the current asPath, not the url

    if (!this.urlIsNew(cleanedAs)) {
      method = 'replaceState';
    }

    const route = (0, _normalizeTrailingSlash.removePathTrailingSlash)(pathname);
    const {
      shallow = false
    } = options;

    if ((0, _isDynamic.isDynamicRoute)(route)) {
      const {
        pathname: asPathname
      } = (0, _parseRelativeUrl.parseRelativeUrl)(cleanedAs);
      const routeRegex = (0, _routeRegex.getRouteRegex)(route);
      const routeMatch = (0, _routeMatcher.getRouteMatcher)(routeRegex)(asPathname);

      if (!routeMatch) {
        const missingParams = Object.keys(routeRegex.groups).filter(param => !query[param]);

        if (missingParams.length > 0) {
          if (false) {}

          throw new Error(`The provided \`as\` value (${asPathname}) is incompatible with the \`href\` value (${route}). ` + `Read more: https://err.sh/vercel/next.js/incompatible-href-as`);
        }
      } else {
        // Merge params into `query`, overwriting any specified in search
        Object.assign(query, routeMatch);
      }
    }

    Router.events.emit('routeChangeStart', as);

    try {
      const routeInfo = await this.getRouteInfo(route, pathname, query, as, shallow);
      const {
        error
      } = routeInfo;
      Router.events.emit('beforeHistoryChange', as);
      this.changeState(method, url, as, options);

      if (false) {}

      await this.set(route, pathname, query, cleanedAs, routeInfo);

      if (error) {
        Router.events.emit('routeChangeError', error, cleanedAs);
        throw error;
      }

      if (false) {}

      Router.events.emit('routeChangeComplete', as);
      return true;
    } catch (err) {
      if (err.cancelled) {
        return false;
      }

      throw err;
    }
  }

  changeState(method, url, as, options = {}) {
    if (false) {}

    if (method !== 'pushState' || (0, _utils.getURL)() !== as) {
      window.history[method]({
        url,
        as,
        options,
        __N: true
      }, // Most browsers currently ignores this parameter, although they may use it in the future.
      // Passing the empty string here should be safe against future changes to the method.
      // https://developer.mozilla.org/en-US/docs/Web/API/History/replaceState
      '', as);
    }
  }

  async handleRouteInfoError(err, pathname, query, as, loadErrorFail) {
    if (err.cancelled) {
      // bubble up cancellation errors
      throw err;
    }

    if (err.code === 'PAGE_LOAD_ERROR' || loadErrorFail) {
      Router.events.emit('routeChangeError', err, as); // If we can't load the page it could be one of following reasons
      //  1. Page doesn't exists
      //  2. Page does exist in a different zone
      //  3. Internal error while loading the page
      // So, doing a hard reload is the proper way to deal with this.

      window.location.href = as; // Changing the URL doesn't block executing the current code path.
      // So let's throw a cancellation error stop the routing logic.

      throw buildCancellationError();
    }

    try {
      const {
        page: Component
      } = await this.fetchComponent('/_error');
      const routeInfo = {
        Component,
        err,
        error: err
      };

      try {
        routeInfo.props = await this.getInitialProps(Component, {
          err,
          pathname,
          query
        });
      } catch (gipErr) {
        console.error('Error in error page `getInitialProps`: ', gipErr);
        routeInfo.props = {};
      }

      return routeInfo;
    } catch (routeInfoErr) {
      return this.handleRouteInfoError(routeInfoErr, pathname, query, as, true);
    }
  }

  async getRouteInfo(route, pathname, query, as, shallow = false) {
    try {
      const cachedRouteInfo = this.components[route];

      if (shallow && cachedRouteInfo && this.route === route) {
        return cachedRouteInfo;
      }

      const routeInfo = cachedRouteInfo ? cachedRouteInfo : await this.fetchComponent(route).then(res => ({
        Component: res.page,
        __N_SSG: res.mod.__N_SSG,
        __N_SSP: res.mod.__N_SSP
      }));
      const {
        Component,
        __N_SSG,
        __N_SSP
      } = routeInfo;

      if (false) {}

      let dataHref;

      if (__N_SSG || __N_SSP) {
        dataHref = this.pageLoader.getDataHref((0, _utils.formatWithValidation)({
          pathname,
          query
        }), as, __N_SSG);
      }

      const props = await this._getData(() => __N_SSG ? this._getStaticData(dataHref) : __N_SSP ? this._getServerData(dataHref) : this.getInitialProps(Component, // we provide AppTree later so this needs to be `any`
      {
        pathname,
        query,
        asPath: as
      }));
      routeInfo.props = props;
      this.components[route] = routeInfo;
      return routeInfo;
    } catch (err) {
      return this.handleRouteInfoError(err, pathname, query, as);
    }
  }

  set(route, pathname, query, as, data) {
    this.isFallback = false;
    this.route = route;
    this.pathname = pathname;
    this.query = query;
    this.asPath = as;
    return this.notify(data);
  }
  /**
  * Callback to execute before replacing router state
  * @param cb callback to be executed
  */


  beforePopState(cb) {
    this._bps = cb;
  }

  onlyAHashChange(as) {
    if (!this.asPath) return false;
    const [oldUrlNoHash, oldHash] = this.asPath.split('#');
    const [newUrlNoHash, newHash] = as.split('#'); // Makes sure we scroll to the provided hash if the url/hash are the same

    if (newHash && oldUrlNoHash === newUrlNoHash && oldHash === newHash) {
      return true;
    } // If the urls are change, there's more than a hash change


    if (oldUrlNoHash !== newUrlNoHash) {
      return false;
    } // If the hash has changed, then it's a hash only change.
    // This check is necessary to handle both the enter and
    // leave hash === '' cases. The identity case falls through
    // and is treated as a next reload.


    return oldHash !== newHash;
  }

  scrollToHash(as) {
    const [, hash] = as.split('#'); // Scroll to top if the hash is just `#` with no value

    if (hash === '') {
      window.scrollTo(0, 0);
      return;
    } // First we check if the element by id is found


    const idEl = document.getElementById(hash);

    if (idEl) {
      idEl.scrollIntoView();
      return;
    } // If there's no element with the id, we check the `name` property
    // To mirror browsers


    const nameEl = document.getElementsByName(hash)[0];

    if (nameEl) {
      nameEl.scrollIntoView();
    }
  }

  urlIsNew(asPath) {
    return this.asPath !== asPath;
  }
  /**
  * Prefetch page code, you may wait for the data during page rendering.
  * This feature only works in production!
  * @param url the href of prefetched page
  * @param asPath the as path of the prefetched page
  */


  async prefetch(url, asPath = url, options = {}) {
    const parsed = tryParseRelativeUrl(url);
    if (!parsed) return;
    const {
      pathname
    } = parsed; // Prefetch is not supported in development mode because it would trigger on-demand-entries

    if (false) {}

    const route = (0, _normalizeTrailingSlash.removePathTrailingSlash)(pathname);
    await Promise.all([this.pageLoader.prefetchData(url, asPath), this.pageLoader[options.priority ? 'loadPage' : 'prefetch'](route)]);
  }

  async fetchComponent(route) {
    let cancelled = false;

    const cancel = this.clc = () => {
      cancelled = true;
    };

    const componentResult = await this.pageLoader.loadPage(route);

    if (cancelled) {
      const error = new Error(`Abort fetching component for route: "${route}"`);
      error.cancelled = true;
      throw error;
    }

    if (cancel === this.clc) {
      this.clc = null;
    }

    return componentResult;
  }

  _getData(fn) {
    let cancelled = false;

    const cancel = () => {
      cancelled = true;
    };

    this.clc = cancel;
    return fn().then(data => {
      if (cancel === this.clc) {
        this.clc = null;
      }

      if (cancelled) {
        const err = new Error('Loading initial props cancelled');
        err.cancelled = true;
        throw err;
      }

      return data;
    });
  }

  _getStaticData(dataHref) {
    const {
      href: cacheKey
    } = new URL(dataHref, window.location.href);

    if ( true && this.sdc[cacheKey]) {
      return Promise.resolve(this.sdc[cacheKey]);
    }

    return fetchNextData(dataHref, this.isSsr).then(data => {
      this.sdc[cacheKey] = data;
      return data;
    });
  }

  _getServerData(dataHref) {
    return fetchNextData(dataHref, this.isSsr);
  }

  getInitialProps(Component, ctx) {
    const {
      Component: App
    } = this.components['/_app'];

    const AppTree = this._wrapApp(App);

    ctx.AppTree = AppTree;
    return (0, _utils.loadGetInitialProps)(App, {
      AppTree,
      Component,
      router: this,
      ctx
    });
  }

  abortComponentLoad(as) {
    if (this.clc) {
      Router.events.emit('routeChangeError', buildCancellationError(), as);
      this.clc();
      this.clc = null;
    }
  }

  notify(data) {
    return this.sub(data, this.components['/_app'].Component);
  }

}

exports.default = Router;
Router.events = (0, _mitt.default)();

/***/ }),

/***/ "g/15":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


exports.__esModule = true;
exports.execOnce = execOnce;
exports.getLocationOrigin = getLocationOrigin;
exports.getURL = getURL;
exports.getDisplayName = getDisplayName;
exports.isResSent = isResSent;
exports.loadGetInitialProps = loadGetInitialProps;
exports.formatWithValidation = formatWithValidation;
exports.ST = exports.SP = exports.urlObjectKeys = void 0;

var _formatUrl = __webpack_require__("6D7l");
/**
* Utils
*/


function execOnce(fn) {
  let used = false;
  let result;
  return (...args) => {
    if (!used) {
      used = true;
      result = fn(...args);
    }

    return result;
  };
}

function getLocationOrigin() {
  const {
    protocol,
    hostname,
    port
  } = window.location;
  return `${protocol}//${hostname}${port ? ':' + port : ''}`;
}

function getURL() {
  const {
    href
  } = window.location;
  const origin = getLocationOrigin();
  return href.substring(origin.length);
}

function getDisplayName(Component) {
  return typeof Component === 'string' ? Component : Component.displayName || Component.name || 'Unknown';
}

function isResSent(res) {
  return res.finished || res.headersSent;
}

async function loadGetInitialProps(App, ctx) {
  if (false) { var _App$prototype; } // when called from _app `ctx` is nested in `ctx`


  const res = ctx.res || ctx.ctx && ctx.ctx.res;

  if (!App.getInitialProps) {
    if (ctx.ctx && ctx.Component) {
      // @ts-ignore pageProps default
      return {
        pageProps: await loadGetInitialProps(ctx.Component, ctx.ctx)
      };
    }

    return {};
  }

  const props = await App.getInitialProps(ctx);

  if (res && isResSent(res)) {
    return props;
  }

  if (!props) {
    const message = `"${getDisplayName(App)}.getInitialProps()" should resolve to an object. But found "${props}" instead.`;
    throw new Error(message);
  }

  if (false) {}

  return props;
}

const urlObjectKeys = ['auth', 'hash', 'host', 'hostname', 'href', 'path', 'pathname', 'port', 'protocol', 'query', 'search', 'slashes'];
exports.urlObjectKeys = urlObjectKeys;

function formatWithValidation(url) {
  if (false) {}

  return (0, _formatUrl.formatUrl)(url);
}

const SP = typeof performance !== 'undefined';
exports.SP = SP;
const ST = SP && typeof performance.mark === 'function' && typeof performance.measure === 'function';
exports.ST = ST;

/***/ }),

/***/ "gguc":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


exports.__esModule = true;
exports.getRouteMatcher = getRouteMatcher;

function getRouteMatcher(routeRegex) {
  const {
    re,
    groups
  } = routeRegex;
  return pathname => {
    const routeMatch = re.exec(pathname);

    if (!routeMatch) {
      return false;
    }

    const decode = param => {
      try {
        return decodeURIComponent(param);
      } catch (_) {
        const err = new Error('failed to decode param');
        err.code = 'DECODE_FAILED';
        throw err;
      }
    };

    const params = {};
    Object.keys(groups).forEach(slugName => {
      const g = groups[slugName];
      const m = routeMatch[g.pos];

      if (m !== undefined) {
        params[slugName] = ~m.indexOf('/') ? m.split('/').map(entry => decode(entry)) : g.repeat ? [decode(m)] : decode(m);
      }
    });
    return params;
  };
}

/***/ }),

/***/ "hS4m":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


exports.__esModule = true;
exports.parseRelativeUrl = parseRelativeUrl;
const DUMMY_BASE = new URL('http://n');
/**
* Parses path-relative urls (e.g. `/hello/world?foo=bar`). If url isn't path-relative
* (e.g. `./hello`) then at least base must be.
* Absolute urls are rejected.
*/

function parseRelativeUrl(url, base) {
  const resolvedBase = base ? new URL(base, DUMMY_BASE) : DUMMY_BASE;
  const {
    pathname,
    searchParams,
    search,
    hash,
    href,
    origin
  } = new URL(url, resolvedBase);

  if (origin !== DUMMY_BASE.origin) {
    throw new Error('invariant: invalid relative URL');
  }

  return {
    pathname,
    searchParams,
    search,
    hash,
    href: href.slice(DUMMY_BASE.origin.length)
  };
}

/***/ }),

/***/ "hXmf":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* WEBPACK VAR INJECTION */(function(__dirname) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return UserVotedrPosts; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("cDcd");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("YFqc");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _chakra_ui_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("WKWs");
/* harmony import */ var _chakra_ui_core__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_chakra_ui_core__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _generated_graphql__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("pHx+");
/* harmony import */ var react_audio_player__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__("5Mv4");
/* harmony import */ var react_audio_player__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_audio_player__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var path__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__("oyvS");
/* harmony import */ var path__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(path__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _UpdootSection__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__("H7a7");
var __jsx = react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement;







const UserVotedrPosts = ({
  postid,
  userid
}) => {
  var _data$post, _data$post2, _data$post3, _data$post4, _data$post5, _data$post6, _data$post7;

  const {
    0: variables,
    1: setVariables
  } = Object(react__WEBPACK_IMPORTED_MODULE_0__["useState"])({
    id: postid,
    limit: 50,
    cursor: null
  });
  const [{
    data: data,
    error,
    fetching
  }] = Object(_generated_graphql__WEBPACK_IMPORTED_MODULE_3__[/* usePostQuery */ "l"])({
    variables: {
      id: postid //   limit: 15,
      // cursor: null as null | string,

    }
  }); // const [{data: userData}] = useUserQuery({
  //   variables:{
  //     id : userid
  //   }
  // })

  const audio_path = path__WEBPACK_IMPORTED_MODULE_5___default.a.join(__dirname, "/files/");
  return __jsx(_chakra_ui_core__WEBPACK_IMPORTED_MODULE_2__["Stack"], null, !data && fetching ? __jsx("div", null, "loading...") : __jsx(_chakra_ui_core__WEBPACK_IMPORTED_MODULE_2__["List"], {
    alignContent: "column"
  }, __jsx(_chakra_ui_core__WEBPACK_IMPORTED_MODULE_2__["Stack"], {
    spacing: 8
  }, __jsx(_chakra_ui_core__WEBPACK_IMPORTED_MODULE_2__["Flex"], {
    key: data === null || data === void 0 ? void 0 : (_data$post = data.post) === null || _data$post === void 0 ? void 0 : _data$post.id,
    p: 5,
    shadow: "md",
    borderWidth: "1px"
  }, __jsx(_UpdootSection__WEBPACK_IMPORTED_MODULE_6__[/* UpdootSection */ "a"], {
    post: data === null || data === void 0 ? void 0 : data.post,
    updaterid: data === null || data === void 0 ? void 0 : (_data$post2 = data.post) === null || _data$post2 === void 0 ? void 0 : _data$post2.updaterId,
    direction: "column",
    disabled: true
  }), __jsx(_chakra_ui_core__WEBPACK_IMPORTED_MODULE_2__["Box"], {
    flex: 1
  }, __jsx(next_link__WEBPACK_IMPORTED_MODULE_1___default.a, {
    href: "/post?uri=[id]",
    as: `/post/${data === null || data === void 0 ? void 0 : (_data$post3 = data.post) === null || _data$post3 === void 0 ? void 0 : _data$post3.id}`
  }, __jsx(_chakra_ui_core__WEBPACK_IMPORTED_MODULE_2__["Link"], null, __jsx(_chakra_ui_core__WEBPACK_IMPORTED_MODULE_2__["Heading"], {
    fontSize: "xl"
  }, data === null || data === void 0 ? void 0 : (_data$post4 = data.post) === null || _data$post4 === void 0 ? void 0 : _data$post4.title))), __jsx(_chakra_ui_core__WEBPACK_IMPORTED_MODULE_2__["Text"], null, "Posted by: ", data === null || data === void 0 ? void 0 : (_data$post5 = data.post) === null || _data$post5 === void 0 ? void 0 : _data$post5.creator.username), __jsx(_chakra_ui_core__WEBPACK_IMPORTED_MODULE_2__["Flex"], {
    align: "center"
  }, __jsx(_chakra_ui_core__WEBPACK_IMPORTED_MODULE_2__["Text"], {
    flex: 1,
    m: 4,
    dir: "auto"
  }, data === null || data === void 0 ? void 0 : (_data$post6 = data.post) === null || _data$post6 === void 0 ? void 0 : _data$post6.textSnippet), __jsx(react_audio_player__WEBPACK_IMPORTED_MODULE_4___default.a, {
    src: audio_path + (data === null || data === void 0 ? void 0 : (_data$post7 = data.post) === null || _data$post7 === void 0 ? void 0 : _data$post7.title) + ".wav",
    controls: true
  }), __jsx(_chakra_ui_core__WEBPACK_IMPORTED_MODULE_2__["Box"], {
    ml: 2
  })))))));
};
/* WEBPACK VAR INJECTION */}.call(this, "/"))

/***/ }),

/***/ "kYf9":
/***/ (function(module, exports) {

module.exports = require("next/dist/next-server/lib/utils.js");

/***/ }),

/***/ "me3I":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return calculateTime; });
// interface calculateTimeprops {
//     secs: number;
//   }
const calculateTime = secs => {
  if (secs == null) {
    return `00:00:00`;
  }

  const hours = Math.floor(secs / 3600);
  const minutes = Math.floor(secs % 3600 / 60);
  const seconds = Math.floor(secs % 60);
  const returnedHours = hours < 10 ? `0${hours}` : `${hours}`;
  const returnedMinutes = minutes < 10 ? `0${minutes}` : `${minutes}`;
  const returnedSeconds = seconds < 10 ? `0${seconds}` : `${seconds}`;
  return `${returnedHours}:${returnedMinutes}:${returnedSeconds}`;
};

/***/ }),

/***/ "nOHt":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _interopRequireWildcard = __webpack_require__("7KCV");

var _interopRequireDefault = __webpack_require__("AroE");

exports.__esModule = true;
exports.useRouter = useRouter;
exports.makePublicRouterInstance = makePublicRouterInstance;
exports.createRouter = exports.withRouter = exports.default = void 0;

var _react = _interopRequireDefault(__webpack_require__("cDcd"));

var _router2 = _interopRequireWildcard(__webpack_require__("elyg"));

exports.Router = _router2.default;
exports.NextRouter = _router2.NextRouter;

var _routerContext = __webpack_require__("Osoz");

var _withRouter = _interopRequireDefault(__webpack_require__("0Bsm"));

exports.withRouter = _withRouter.default;
/* global window */

const singletonRouter = {
  router: null,
  // holds the actual router instance
  readyCallbacks: [],

  ready(cb) {
    if (this.router) return cb();

    if (false) {}
  }

}; // Create public properties and methods of the router in the singletonRouter

const urlPropertyFields = ['pathname', 'route', 'query', 'asPath', 'components', 'isFallback', 'basePath'];
const routerEvents = ['routeChangeStart', 'beforeHistoryChange', 'routeChangeComplete', 'routeChangeError', 'hashChangeStart', 'hashChangeComplete'];
const coreMethodFields = ['push', 'replace', 'reload', 'back', 'prefetch', 'beforePopState']; // Events is a static property on the router, the router doesn't have to be initialized to use it

Object.defineProperty(singletonRouter, 'events', {
  get() {
    return _router2.default.events;
  }

});
urlPropertyFields.forEach(field => {
  // Here we need to use Object.defineProperty because, we need to return
  // the property assigned to the actual router
  // The value might get changed as we change routes and this is the
  // proper way to access it
  Object.defineProperty(singletonRouter, field, {
    get() {
      const router = getRouter();
      return router[field];
    }

  });
});
coreMethodFields.forEach(field => {
  // We don't really know the types here, so we add them later instead
  ;

  singletonRouter[field] = (...args) => {
    const router = getRouter();
    return router[field](...args);
  };
});
routerEvents.forEach(event => {
  singletonRouter.ready(() => {
    _router2.default.events.on(event, (...args) => {
      const eventField = `on${event.charAt(0).toUpperCase()}${event.substring(1)}`;
      const _singletonRouter = singletonRouter;

      if (_singletonRouter[eventField]) {
        try {
          _singletonRouter[eventField](...args);
        } catch (err) {
          // tslint:disable-next-line:no-console
          console.error(`Error when running the Router event: ${eventField}`); // tslint:disable-next-line:no-console

          console.error(`${err.message}\n${err.stack}`);
        }
      }
    });
  });
});

function getRouter() {
  if (!singletonRouter.router) {
    const message = 'No router instance found.\n' + 'You should only use "next/router" inside the client side of your app.\n';
    throw new Error(message);
  }

  return singletonRouter.router;
} // Export the singletonRouter and this is the public API.


var _default = singletonRouter; // Reexport the withRoute HOC

exports.default = _default;

function useRouter() {
  return _react.default.useContext(_routerContext.RouterContext);
} // INTERNAL APIS
// -------------
// (do not use following exports inside the app)
// Create a router and assign it as the singleton instance.
// This is used in client side when we are initilizing the app.
// This should **not** use inside the server.


const createRouter = (...args) => {
  singletonRouter.router = new _router2.default(...args);
  singletonRouter.readyCallbacks.forEach(cb => cb());
  singletonRouter.readyCallbacks = [];
  return singletonRouter.router;
}; // This function is used to create the `withRouter` router instance


exports.createRouter = createRouter;

function makePublicRouterInstance(router) {
  const _router = router;
  const instance = {};

  for (const property of urlPropertyFields) {
    if (typeof _router[property] === 'object') {
      instance[property] = Object.assign({}, _router[property]); // makes sure query is not stateful

      continue;
    }

    instance[property] = _router[property];
  } // Events is a static property on the router, the router doesn't have to be initialized to use it


  instance.events = _router2.default.events;
  coreMethodFields.forEach(field => {
    instance[field] = (...args) => {
      return _router[field](...args);
    };
  });
  return instance;
}

/***/ }),

/***/ "oyvS":
/***/ (function(module, exports) {

module.exports = require("path");

/***/ }),

/***/ "pHx+":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* unused harmony export PostSnippetFragmentDoc */
/* unused harmony export RegularPostErrorFragmentDoc */
/* unused harmony export RegularErrorFragmentDoc */
/* unused harmony export RegularUserFragmentDoc */
/* unused harmony export RegularUserResponseFragmentDoc */
/* unused harmony export ActivateUserDocument */
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "b", function() { return useActivateUserMutation; });
/* unused harmony export ChangePasswordDocument */
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "c", function() { return useChangePasswordMutation; });
/* unused harmony export CreatePostDocument */
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "d", function() { return useCreatePostMutation; });
/* unused harmony export DeactivateUserDocument */
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "e", function() { return useDeactivateUserMutation; });
/* unused harmony export DeletePostDocument */
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "f", function() { return useDeletePostMutation; });
/* unused harmony export ForgotPasswordDocument */
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "h", function() { return useForgotPasswordMutation; });
/* unused harmony export LoginDocument */
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "i", function() { return useLoginMutation; });
/* unused harmony export LogoutDocument */
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "j", function() { return useLogoutMutation; });
/* unused harmony export RegisterDocument */
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "n", function() { return useRegisterMutation; });
/* unused harmony export UpdatePostDocument */
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "o", function() { return useUpdatePostMutation; });
/* unused harmony export VoteDocument */
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "v", function() { return useVoteMutation; });
/* unused harmony export EditablePostsDocument */
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "g", function() { return useEditablePostsQuery; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return MeDocument; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "k", function() { return useMeQuery; });
/* unused harmony export PostDocument */
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "l", function() { return usePostQuery; });
/* unused harmony export PostsDocument */
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "m", function() { return usePostsQuery; });
/* unused harmony export UserDocument */
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "r", function() { return useUserQuery; });
/* unused harmony export UserDurationsDocument */
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "p", function() { return useUserDurationsQuery; });
/* unused harmony export UserPostsDocument */
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "q", function() { return useUserPostsQuery; });
/* unused harmony export UsersDocument */
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "u", function() { return useUsersQuery; });
/* unused harmony export UsersDurationsDocument */
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "t", function() { return useUsersDurationsQuery; });
/* unused harmony export UserVotedPostsDocument */
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "s", function() { return useUserVotedPostsQuery; });
/* unused harmony export VottablePostsDocument */
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "w", function() { return useVottablePostsQuery; });
/* harmony import */ var graphql_tag__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("txk1");
/* harmony import */ var graphql_tag__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(graphql_tag__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var urql__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("5X2e");
/* harmony import */ var urql__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(urql__WEBPACK_IMPORTED_MODULE_1__);
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }



const PostSnippetFragmentDoc = graphql_tag__WEBPACK_IMPORTED_MODULE_0___default.a`
    fragment PostSnippet on Post {
  id
  createdAt
  updatedAt
  title
  text
  duration
  updaterId
  points
  textSnippet
  voteStatus
  creator {
    id
    username
  }
}
    `;
const RegularPostErrorFragmentDoc = graphql_tag__WEBPACK_IMPORTED_MODULE_0___default.a`
    fragment RegularPostError on PostFieldError {
  field
  message
}
    `;
const RegularErrorFragmentDoc = graphql_tag__WEBPACK_IMPORTED_MODULE_0___default.a`
    fragment RegularError on FieldError {
  field
  message
}
    `;
const RegularUserFragmentDoc = graphql_tag__WEBPACK_IMPORTED_MODULE_0___default.a`
    fragment RegularUser on User {
  id
  username
  role
  active
}
    `;
const RegularUserResponseFragmentDoc = graphql_tag__WEBPACK_IMPORTED_MODULE_0___default.a`
    fragment RegularUserResponse on UserResponse {
  errors {
    ...RegularError
  }
  user {
    ...RegularUser
  }
}
    ${RegularErrorFragmentDoc}
${RegularUserFragmentDoc}`;
const ActivateUserDocument = graphql_tag__WEBPACK_IMPORTED_MODULE_0___default.a`
    mutation ActivateUser($id: Int!) {
  activateuser(id: $id)
}
    `;
function useActivateUserMutation() {
  return urql__WEBPACK_IMPORTED_MODULE_1__["useMutation"](ActivateUserDocument);
}
;
const ChangePasswordDocument = graphql_tag__WEBPACK_IMPORTED_MODULE_0___default.a`
    mutation ChangePassword($token: String!, $newPassword: String!) {
  changePassword(token: $token, newPassword: $newPassword) {
    ...RegularUserResponse
  }
}
    ${RegularUserResponseFragmentDoc}`;
function useChangePasswordMutation() {
  return urql__WEBPACK_IMPORTED_MODULE_1__["useMutation"](ChangePasswordDocument);
}
;
const CreatePostDocument = graphql_tag__WEBPACK_IMPORTED_MODULE_0___default.a`
    mutation CreatePost($input: PostInput!) {
  createPost(input: $input) {
    id
    createdAt
    updatedAt
    title
    text
    points
    creatorId
  }
}
    `;
function useCreatePostMutation() {
  return urql__WEBPACK_IMPORTED_MODULE_1__["useMutation"](CreatePostDocument);
}
;
const DeactivateUserDocument = graphql_tag__WEBPACK_IMPORTED_MODULE_0___default.a`
    mutation DeactivateUser($id: Int!) {
  deactivateuser(id: $id)
}
    `;
function useDeactivateUserMutation() {
  return urql__WEBPACK_IMPORTED_MODULE_1__["useMutation"](DeactivateUserDocument);
}
;
const DeletePostDocument = graphql_tag__WEBPACK_IMPORTED_MODULE_0___default.a`
    mutation DeletePost($id: Int!) {
  deletePost(id: $id)
}
    `;
function useDeletePostMutation() {
  return urql__WEBPACK_IMPORTED_MODULE_1__["useMutation"](DeletePostDocument);
}
;
const ForgotPasswordDocument = graphql_tag__WEBPACK_IMPORTED_MODULE_0___default.a`
    mutation ForgotPassword($email: String!) {
  forgotPassword(email: $email)
}
    `;
function useForgotPasswordMutation() {
  return urql__WEBPACK_IMPORTED_MODULE_1__["useMutation"](ForgotPasswordDocument);
}
;
const LoginDocument = graphql_tag__WEBPACK_IMPORTED_MODULE_0___default.a`
    mutation Login($usernameOrEmail: String!, $password: String!) {
  login(usernameOrEmail: $usernameOrEmail, password: $password) {
    ...RegularUserResponse
  }
}
    ${RegularUserResponseFragmentDoc}`;
function useLoginMutation() {
  return urql__WEBPACK_IMPORTED_MODULE_1__["useMutation"](LoginDocument);
}
;
const LogoutDocument = graphql_tag__WEBPACK_IMPORTED_MODULE_0___default.a`
    mutation Logout {
  logout
}
    `;
function useLogoutMutation() {
  return urql__WEBPACK_IMPORTED_MODULE_1__["useMutation"](LogoutDocument);
}
;
const RegisterDocument = graphql_tag__WEBPACK_IMPORTED_MODULE_0___default.a`
    mutation Register($options: UsernamePasswordInput!) {
  register(options: $options) {
    ...RegularUserResponse
  }
}
    ${RegularUserResponseFragmentDoc}`;
function useRegisterMutation() {
  return urql__WEBPACK_IMPORTED_MODULE_1__["useMutation"](RegisterDocument);
}
;
const UpdatePostDocument = graphql_tag__WEBPACK_IMPORTED_MODULE_0___default.a`
    mutation UpdatePost($options: PostTextinput!) {
  updatePost(options: $options) {
    errors {
      ...RegularPostError
    }
    post {
      id
      text
      updaterId
      textSnippet
      createdAt
      updatedAt
    }
  }
}
    ${RegularPostErrorFragmentDoc}`;
function useUpdatePostMutation() {
  return urql__WEBPACK_IMPORTED_MODULE_1__["useMutation"](UpdatePostDocument);
}
;
const VoteDocument = graphql_tag__WEBPACK_IMPORTED_MODULE_0___default.a`
    mutation Vote($value: Int!, $postId: Int!) {
  vote(value: $value, postId: $postId)
}
    `;
function useVoteMutation() {
  return urql__WEBPACK_IMPORTED_MODULE_1__["useMutation"](VoteDocument);
}
;
const EditablePostsDocument = graphql_tag__WEBPACK_IMPORTED_MODULE_0___default.a`
    query EditablePosts($limit: Int!, $cursor: String) {
  editableposts(limit: $limit, cursor: $cursor) {
    hasMore
    posts {
      ...PostSnippet
    }
  }
}
    ${PostSnippetFragmentDoc}`;
function useEditablePostsQuery(options = {}) {
  return urql__WEBPACK_IMPORTED_MODULE_1__["useQuery"](_objectSpread({
    query: EditablePostsDocument
  }, options));
}
;
const MeDocument = graphql_tag__WEBPACK_IMPORTED_MODULE_0___default.a`
    query Me {
  me {
    ...RegularUser
  }
}
    ${RegularUserFragmentDoc}`;
function useMeQuery(options = {}) {
  return urql__WEBPACK_IMPORTED_MODULE_1__["useQuery"](_objectSpread({
    query: MeDocument
  }, options));
}
;
const PostDocument = graphql_tag__WEBPACK_IMPORTED_MODULE_0___default.a`
    query Post($id: Int!) {
  post(id: $id) {
    ...PostSnippet
  }
}
    ${PostSnippetFragmentDoc}`;
function usePostQuery(options = {}) {
  return urql__WEBPACK_IMPORTED_MODULE_1__["useQuery"](_objectSpread({
    query: PostDocument
  }, options));
}
;
const PostsDocument = graphql_tag__WEBPACK_IMPORTED_MODULE_0___default.a`
    query Posts($limit: Int!, $cursor: String) {
  posts(limit: $limit, cursor: $cursor) {
    hasMore
    posts {
      ...PostSnippet
    }
  }
}
    ${PostSnippetFragmentDoc}`;
function usePostsQuery(options = {}) {
  return urql__WEBPACK_IMPORTED_MODULE_1__["useQuery"](_objectSpread({
    query: PostsDocument
  }, options));
}
;
const UserDocument = graphql_tag__WEBPACK_IMPORTED_MODULE_0___default.a`
    query User($id: Int!) {
  user(id: $id) {
    id
    username
    role
    active
  }
}
    `;
function useUserQuery(options = {}) {
  return urql__WEBPACK_IMPORTED_MODULE_1__["useQuery"](_objectSpread({
    query: UserDocument
  }, options));
}
;
const UserDurationsDocument = graphql_tag__WEBPACK_IMPORTED_MODULE_0___default.a`
    query UserDurations($updaterId: Int!) {
  userdurations(updaterId: $updaterId) {
    sum
    count
  }
}
    `;
function useUserDurationsQuery(options = {}) {
  return urql__WEBPACK_IMPORTED_MODULE_1__["useQuery"](_objectSpread({
    query: UserDurationsDocument
  }, options));
}
;
const UserPostsDocument = graphql_tag__WEBPACK_IMPORTED_MODULE_0___default.a`
    query UserPosts($updaterId: Int!, $limit: Int!, $cursor: String) {
  userposts(updaterId: $updaterId, limit: $limit, cursor: $cursor) {
    hasMore
    posts {
      ...PostSnippet
    }
  }
}
    ${PostSnippetFragmentDoc}`;
function useUserPostsQuery(options = {}) {
  return urql__WEBPACK_IMPORTED_MODULE_1__["useQuery"](_objectSpread({
    query: UserPostsDocument
  }, options));
}
;
const UsersDocument = graphql_tag__WEBPACK_IMPORTED_MODULE_0___default.a`
    query Users {
  users {
    id
    username
    email
    role
    active
  }
}
    `;
function useUsersQuery(options = {}) {
  return urql__WEBPACK_IMPORTED_MODULE_1__["useQuery"](_objectSpread({
    query: UsersDocument
  }, options));
}
;
const UsersDurationsDocument = graphql_tag__WEBPACK_IMPORTED_MODULE_0___default.a`
    query UsersDurations {
  usersdurations {
    sum
  }
}
    `;
function useUsersDurationsQuery(options = {}) {
  return urql__WEBPACK_IMPORTED_MODULE_1__["useQuery"](_objectSpread({
    query: UsersDurationsDocument
  }, options));
}
;
const UserVotedPostsDocument = graphql_tag__WEBPACK_IMPORTED_MODULE_0___default.a`
    query UserVotedPosts($updaterId: Int!, $limit: Int!, $cursor: String) {
  uservotedposts(updaterId: $updaterId, limit: $limit, cursor: $cursor) {
    hasMore
    votedposts {
      value
      userId
      postId
    }
  }
}
    `;
function useUserVotedPostsQuery(options = {}) {
  return urql__WEBPACK_IMPORTED_MODULE_1__["useQuery"](_objectSpread({
    query: UserVotedPostsDocument
  }, options));
}
;
const VottablePostsDocument = graphql_tag__WEBPACK_IMPORTED_MODULE_0___default.a`
    query VottablePosts($limit: Int!, $cursor: String) {
  votableposts(limit: $limit, cursor: $cursor) {
    hasMore
    posts {
      ...PostSnippet
    }
  }
}
    ${PostSnippetFragmentDoc}`;
function useVottablePostsQuery(options = {}) {
  return urql__WEBPACK_IMPORTED_MODULE_1__["useQuery"](_objectSpread({
    query: VottablePostsDocument
  }, options));
}
;

/***/ }),

/***/ "soUV":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, "a", function() { return /* binding */ Layout; });

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__("cDcd");
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);

// EXTERNAL MODULE: ./src/components/Wrapper.tsx
var Wrapper = __webpack_require__("uHth");

// EXTERNAL MODULE: external "@chakra-ui/core"
var core_ = __webpack_require__("WKWs");

// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__("YFqc");
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);

// EXTERNAL MODULE: ./src/generated/graphql.tsx
var graphql = __webpack_require__("pHx+");

// EXTERNAL MODULE: ./src/utils/isServer.ts
var isServer = __webpack_require__("OXnp");

// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__("4Q3z");

// CONCATENATED MODULE: ./src/components/NavBar.tsx
var __jsx = external_react_default.a.createElement;






const NavBar = ({}) => {
  const router = Object(router_["useRouter"])();
  const [{
    fetching: logoutFetching
  }, logout] = Object(graphql["j" /* useLogoutMutation */])();
  const [{
    data,
    fetching
  }] = Object(graphql["k" /* useMeQuery */])({
    pause: Object(isServer["a" /* isServer */])()
  });
  {
    /* <svg class="logo" viewBox="0 0 128 128" xmlns:xlink="http://www.w3.org/1999/xlink">
    <title>GraphQL Playground Logo</title>
    <defs>
    <linearGradient id="linearGradient-1" x1="4.86%" x2="96.21%" y1="0%" y2="99.66%">
      <stop stop-color="#E00082" stop-opacity=".8" offset="0%"></stop>
      <stop stop-color="#E00082" offset="100%"></stop>
    </linearGradient>
    </defs>
    <g>
    <rect id="Gradient" width="127.96" height="127.96" y="1" fill="url(#linearGradient-1)" rx="4"></rect>
    <path id="Border" fill="#E00082" fill-rule="nonzero" d="M4.7 2.84c-1.58 0-2.86 1.28-2.86 2.85v116.57c0 1.57 1.28 2.84 2.85 2.84h116.57c1.57 0 2.84-1.26 2.84-2.83V5.67c0-1.55-1.26-2.83-2.83-2.83H4.67zM4.7 0h116.58c3.14 0 5.68 2.55 5.68 5.7v116.58c0 3.14-2.54 5.68-5.68 5.68H4.68c-3.13 0-5.68-2.54-5.68-5.68V5.68C-1 2.56 1.55 0 4.7 0z"></path>
    <path class="bglIGM" x="64" y="28" fill="#fff" d="M64 36c-4.42 0-8-3.58-8-8s3.58-8 8-8 8 3.58 8 8-3.58 8-8 8" style="transform: translate(100px, 100px);"></path>
    <path class="ksxRII" x="95.98500061035156" y="46.510000228881836" fill="#fff" d="M89.04 50.52c-2.2-3.84-.9-8.73 2.94-10.96 3.83-2.2 8.72-.9 10.95 2.94 2.2 3.84.9 8.73-2.94 10.96-3.85 2.2-8.76.9-10.97-2.94" style="transform: translate(100px, 100px);"></path>
    <path class="cWrBmb" x="95.97162628173828" y="83.4900016784668" fill="#fff" d="M102.9 87.5c-2.2 3.84-7.1 5.15-10.94 2.94-3.84-2.2-5.14-7.12-2.94-10.96 2.2-3.84 7.12-5.15 10.95-2.94 3.86 2.23 5.16 7.12 2.94 10.96" style="transform: translate(100px, 100px);"></path>
    <path class="Wnusb" x="64" y="101.97999572753906" fill="#fff" d="M64 110c-4.43 0-8-3.6-8-8.02 0-4.44 3.57-8.02 8-8.02s8 3.58 8 8.02c0 4.4-3.57 8.02-8 8.02" style="transform: translate(100px, 100px);"></path>
    <path class="bfPqf" x="32.03982162475586" y="83.4900016784668" fill="#fff" d="M25.1 87.5c-2.2-3.84-.9-8.73 2.93-10.96 3.83-2.2 8.72-.9 10.95 2.94 2.2 3.84.9 8.73-2.94 10.96-3.85 2.2-8.74.9-10.95-2.94" style="transform: translate(100px, 100px);"></path>
    <path class="edRCTN" x="32.033552169799805" y="46.510000228881836" fill="#fff" d="M38.96 50.52c-2.2 3.84-7.12 5.15-10.95 2.94-3.82-2.2-5.12-7.12-2.92-10.96 2.2-3.84 7.12-5.15 10.95-2.94 3.83 2.23 5.14 7.12 2.94 10.96" style="transform: translate(100px, 100px);"></path>
    <path class="iEGVWn" stroke="#fff" stroke-width="4" stroke-linecap="round" stroke-linejoin="round" d="M63.55 27.5l32.9 19-32.9-19z"></path>
    <path class="bsocdx" stroke="#fff" stroke-width="4" stroke-linecap="round" stroke-linejoin="round" d="M96 46v38-38z"></path>
    <path class="jAZXmP" stroke="#fff" stroke-width="4" stroke-linecap="round" stroke-linejoin="round" d="M96.45 84.5l-32.9 19 32.9-19z"></path>
    <path class="hSeArx" stroke="#fff" stroke-width="4" stroke-linecap="round" stroke-linejoin="round" d="M64.45 103.5l-32.9-19 32.9 19z"></path>
    <path class="bVgqGk" stroke="#fff" stroke-width="4" stroke-linecap="round" stroke-linejoin="round" d="M32 84V46v38z"></path>
    <path class="hEFqBt" stroke="#fff" stroke-width="4" stroke-linecap="round" stroke-linejoin="round" d="M31.55 46.5l32.9-19-32.9 19z"></path>
    <path class="dzEKCM" id="Triangle-Bottom" stroke="#fff" stroke-width="4" d="M30 84h70" stroke-linecap="round"></path>
    <path class="DYnPx" id="Triangle-Left" stroke="#fff" stroke-width="4" d="M65 26L30 87" stroke-linecap="round"></path>
    <path class="hjPEAQ" id="Triangle-Right" stroke="#fff" stroke-width="4" d="M98 87L63 26" stroke-linecap="round"></path>
    </g>
    </svg> */
  }

  const Logo = props => {
    return __jsx("img", {
      height: "74",
      width: "74",
      "max-width": "min-content",
      src: "/oook_no-bg.svg"
    });
  };

  let body = null; // data is loading

  if (fetching) {// user not logged in
  } else if (!(data === null || data === void 0 ? void 0 : data.me)) {
    body = __jsx(external_react_default.a.Fragment, null, __jsx(link_default.a, {
      href: "/Account/login"
    }, __jsx(core_["Link"], {
      mr: 2
    }, "login")), __jsx(link_default.a, {
      href: "/Account/register"
    }, __jsx(core_["Link"], null, "register"))); // user is logged in
  } else {
    body = __jsx(core_["Flex"], {
      align: "center"
    }, __jsx(core_["Box"], {
      alignSelf: "center"
    }, __jsx(link_default.a, {
      href: "/editable-posts"
    }, __jsx(core_["IconButton"], {
      "aria-label": "updoot post",
      icon: "drag-handle",
      as: core_["Link"],
      mr: 4,
      bg: "orange.200"
    }))), __jsx(core_["Box"], {
      mr: 2
    }, __jsx(link_default.a, {
      href: "/posts"
    }, __jsx(core_["Link"], null, data.me.username))), __jsx(core_["Button"], {
      onClick: async () => {
        await logout();
        router.reload();
      },
      isLoading: logoutFetching,
      variant: "link"
    }, "logout"));
  }

  return __jsx(core_["Flex"], {
    zIndex: 5,
    position: "sticky",
    top: 0,
    bg: "orange.200",
    color: "orange.700",
    p: 4
  }, __jsx(core_["Flex"], {
    flex: 1,
    m: "auto",
    align: "center",
    maxW: 800
  }, __jsx(link_default.a, {
    href: "/"
  }, __jsx(core_["Link"], null, __jsx(core_["Heading"], null, "OOOK - \u0639\u0648\u0648\u0643 "))), __jsx(core_["Box"], {
    ml: "auto"
  }, body)));
};
// CONCATENATED MODULE: ./src/components/Footer.tsx
var Footer_jsx = external_react_default.a.createElement;




const Footer_Logo = props => {
  return Footer_jsx("img", {
    height: "92",
    width: "92",
    "aria-label": "oook icon",
    "max-width": "min-content",
    src: "/oook.svg"
  });
};

const Footer = ({}) => {
  let body = Footer_jsx(core_["Flex"], {
    as: core_["Stack"],
    maxW: "6xl",
    py: 20,
    position: "sticky",
    direction: {
      base: "column",
      md: "row"
    },
    p: 4,
    justify: {
      base: "center",
      md: "space-between"
    },
    align: {
      base: "center",
      md: "center"
    }
  }, Footer_jsx(core_["Stack"], {
    gridColumn: 2,
    direction: "column"
  }, Footer_jsx(link_default.a, {
    href: "/about"
  }, Footer_jsx(core_["Link"], {
    flexDirection: "-moz-initial",
    position: "relative",
    mr: 10
  }, "About")), Footer_jsx(core_["Link"], {
    href: "mailto:support@oook.sd"
  }, "Report an issue"), Footer_jsx(core_["Text"], null, "Designed by", " ", ": ", " ", Footer_jsx(core_["Link"], {
    href: "https://www.ayman-mansour.com",
    target: "_blank",
    rel: "From oook.sd"
  }, "Ayman Mansour"))));

  return Footer_jsx(core_["Flex"], {
    zIndex: 1,
    bottom: "",
    position: "sticky",
    bg: "orange.200",
    color: "orange.700",
    p: 4
  }, Footer_jsx(core_["Flex"], {
    flex: 0.5,
    m: "auto",
    align: "center",
    maxW: 800
  }, Footer_jsx(Footer_Logo, null), Footer_jsx(core_["Box"], {
    ml: "auto"
  }, body))) //     <Box
  //     bg={'orange.200'}
  //     color={'orange.700'}>
  //     <Flex
  //       as={Stack}
  //       maxW={'6xl'}
  //       py={4}
  //       direction={{ base: 'column', md: 'row' }}
  //       p={4}
  //       justify={{ base: 'center', md: 'space-between' }}
  //       align={{ base: 'center', md: 'center' }}>
  //       <Logo />
  //     </Flex>
  //   </Box>
  ;
};
// CONCATENATED MODULE: ./src/components/Layout.tsx
var Layout_jsx = external_react_default.a.createElement;





const Layout = ({
  children,
  variant
}) => {
  return Layout_jsx(external_react_default.a.Fragment, null, Layout_jsx(NavBar, null), Layout_jsx(core_["Box"], {
    bg: 'orange.200',
    color: 'orange.300'
  }), " ", Layout_jsx(Wrapper["a" /* Wrapper */], {
    variant: variant
  }, children), Layout_jsx(Footer, null));
};

/***/ }),

/***/ "txk1":
/***/ (function(module, exports) {

module.exports = require("graphql-tag");

/***/ }),

/***/ "uHth":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return Wrapper; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("cDcd");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _chakra_ui_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("WKWs");
/* harmony import */ var _chakra_ui_core__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_chakra_ui_core__WEBPACK_IMPORTED_MODULE_1__);
var __jsx = react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement;


const Wrapper = ({
  children,
  variant = "regular"
}) => {
  return __jsx(_chakra_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
    mt: 8,
    mb: 8,
    mx: "auto",
    maxW: variant === "regular" ? "800px" : "400px" // w="100%"
    // h="100%"

  }, children);
};

/***/ }),

/***/ "xKEG":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return useGetIntId; });
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("4Q3z");
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_0__);

const useGetIntId = () => {
  const router = Object(next_router__WEBPACK_IMPORTED_MODULE_0__["useRouter"])();
  const intId = typeof router.query.id === "string" ? parseInt(router.query.id) : -1;
  return intId;
};

/***/ }),

/***/ "ypBt":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* WEBPACK VAR INJECTION */(function(__dirname) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return UserPosts; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("cDcd");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("YFqc");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _chakra_ui_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("WKWs");
/* harmony import */ var _chakra_ui_core__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_chakra_ui_core__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _generated_graphql__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("pHx+");
/* harmony import */ var _UserPostsDurations__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__("HdUH");
/* harmony import */ var _EditDeletePostButtons__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__("4Tsm");
/* harmony import */ var react_audio_player__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__("5Mv4");
/* harmony import */ var react_audio_player__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_audio_player__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var path__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__("oyvS");
/* harmony import */ var path__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(path__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _UserVotedPosts__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__("hXmf");
var __jsx = react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement;









const UserPosts = ({
  uid
}) => {
  const {
    0: variables,
    1: setVariables
  } = Object(react__WEBPACK_IMPORTED_MODULE_0__["useState"])({
    updaterId: uid,
    limit: 50,
    cursor: null
  });
  const [{
    data: data,
    error,
    fetching
  }] = Object(_generated_graphql__WEBPACK_IMPORTED_MODULE_3__[/* useUserPostsQuery */ "q"])({
    variables: {
      updaterId: uid,
      limit: 15,
      cursor: null
    }
  });
  const [{
    data: userData
  }] = Object(_generated_graphql__WEBPACK_IMPORTED_MODULE_3__[/* useUserQuery */ "r"])({
    variables: {
      id: uid
    }
  });
  const [{
    data: voteData
  }] = Object(_generated_graphql__WEBPACK_IMPORTED_MODULE_3__[/* useUserVotedPostsQuery */ "s"])({
    variables
  });
  const audio_path = path__WEBPACK_IMPORTED_MODULE_7___default.a.join(__dirname, "/files/");

  if ((userData === null || userData === void 0 ? void 0 : userData.user[0].role) == "Reviewer") {
    return __jsx(react__WEBPACK_IMPORTED_MODULE_0___default.a.Fragment, null, __jsx(_chakra_ui_core__WEBPACK_IMPORTED_MODULE_2__["Flex"], {
      p: 5,
      shadow: "md",
      bg: "orange.50",
      m: 5,
      borderRadius: 5,
      borderWidth: "1px"
    }, __jsx(_chakra_ui_core__WEBPACK_IMPORTED_MODULE_2__["Box"], null, __jsx(_chakra_ui_core__WEBPACK_IMPORTED_MODULE_2__["Heading"], {
      fontSize: "xl"
    }, "Name : ", userData === null || userData === void 0 ? void 0 : userData.user[0].username), __jsx(_chakra_ui_core__WEBPACK_IMPORTED_MODULE_2__["Heading"], {
      fontSize: "xl"
    }, "Reviewed posts : ", voteData === null || voteData === void 0 ? void 0 : voteData.uservotedposts.votedposts.length, " ", "posts"))), __jsx(_chakra_ui_core__WEBPACK_IMPORTED_MODULE_2__["Heading"], {
      fontSize: "xl",
      m: 5
    }, "Posts"), voteData === null || voteData === void 0 ? void 0 : voteData.uservotedposts.votedposts.map(up => !up ? null : __jsx(_UserVotedPosts__WEBPACK_IMPORTED_MODULE_8__[/* UserVotedrPosts */ "a"], {
      postid: up.postId,
      userid: up.userId
    })));
  } else {
    return __jsx(_chakra_ui_core__WEBPACK_IMPORTED_MODULE_2__["Stack"], null, !data && fetching ? __jsx("div", null, "loading...") : __jsx(_chakra_ui_core__WEBPACK_IMPORTED_MODULE_2__["List"], {
      alignContent: "column"
    }, __jsx(_chakra_ui_core__WEBPACK_IMPORTED_MODULE_2__["Stack"], {
      spacing: 8
    }, __jsx(react__WEBPACK_IMPORTED_MODULE_0___default.a.Fragment, null, __jsx(_chakra_ui_core__WEBPACK_IMPORTED_MODULE_2__["Flex"], {
      p: 5,
      shadow: "md",
      bg: "orange.50",
      m: 5,
      borderRadius: 5,
      borderWidth: "1px"
    }, __jsx(_chakra_ui_core__WEBPACK_IMPORTED_MODULE_2__["Box"], null, __jsx(_chakra_ui_core__WEBPACK_IMPORTED_MODULE_2__["Heading"], {
      fontSize: "xl"
    }, "Name : ", userData === null || userData === void 0 ? void 0 : userData.user[0].username), __jsx(_chakra_ui_core__WEBPACK_IMPORTED_MODULE_2__["Heading"], {
      fontSize: "xl"
    }, __jsx(_UserPostsDurations__WEBPACK_IMPORTED_MODULE_4__[/* UserPostsDurations */ "a"], {
      updaterId: userData === null || userData === void 0 ? void 0 : userData.user[0].id
    })))), __jsx(_chakra_ui_core__WEBPACK_IMPORTED_MODULE_2__["Heading"], {
      fontSize: "xl",
      m: 5
    }, "Posts")), data === null || data === void 0 ? void 0 : data.userposts.posts.map(p => !p ? null : __jsx(_chakra_ui_core__WEBPACK_IMPORTED_MODULE_2__["Flex"], {
      key: p.id,
      p: 5,
      shadow: "md",
      borderWidth: "1px"
    }, __jsx(_chakra_ui_core__WEBPACK_IMPORTED_MODULE_2__["Box"], {
      flex: 1
    }, __jsx(next_link__WEBPACK_IMPORTED_MODULE_1___default.a, {
      href: "/post?uri=[id]",
      as: `/post/${p.id}`
    }, __jsx(_chakra_ui_core__WEBPACK_IMPORTED_MODULE_2__["Link"], null, __jsx(_chakra_ui_core__WEBPACK_IMPORTED_MODULE_2__["Heading"], {
      fontSize: "xl"
    }, p.title))), __jsx(_chakra_ui_core__WEBPACK_IMPORTED_MODULE_2__["Text"], null, "Posted by: ", p.creator.username), __jsx(_chakra_ui_core__WEBPACK_IMPORTED_MODULE_2__["Flex"], {
      align: "center"
    }, __jsx(_chakra_ui_core__WEBPACK_IMPORTED_MODULE_2__["Text"], {
      flex: 1,
      mt: 4,
      dir: "auto"
    }, p.textSnippet), __jsx(react_audio_player__WEBPACK_IMPORTED_MODULE_6___default.a, {
      src: audio_path + p.title + ".wav",
      controls: true,
      loop: true
    }), __jsx(_chakra_ui_core__WEBPACK_IMPORTED_MODULE_2__["Box"], {
      ml: 2
    }, __jsx(_EditDeletePostButtons__WEBPACK_IMPORTED_MODULE_5__[/* EditDeletePostButtons */ "a"], {
      id: p.id,
      creatorId: p.creator.id,
      updaterId: p.updaterId
    })))))))), data && data.userposts.hasMore ? __jsx(_chakra_ui_core__WEBPACK_IMPORTED_MODULE_2__["Flex"], null, __jsx(_chakra_ui_core__WEBPACK_IMPORTED_MODULE_2__["Button"], {
      onClick: () => {
        setVariables({
          updaterId: variables.updaterId,
          limit: variables.limit,
          cursor: data.userposts.posts[data.userposts.posts.length - 1].updatedAt
        });
      },
      isLoading: fetching,
      m: "auto",
      my: 8
    }, "load more")) : null);
  }
};
/* WEBPACK VAR INJECTION */}.call(this, "/"))

/***/ })

/******/ });